﻿using DevExpress.XtraEditors;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Çoklu_dil_çeviri_uygulaması
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Metni ceviren ana fonksiyon 
        public string MetniCevir(string metin, string kaynak, string hedef)
        {
            try
            {
                // Gercek bir ceviri icin Google veya Yandex API kullanilabilir.
                // Bu ornekte basit bir web servisi mantigi simüle edilmistir.

                if (string.IsNullOrWhiteSpace(metin)) return "";

                // API baglantisi simülasyonu 
                string url = $"https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl={hedef}&dt=t&q={Uri.EscapeDataString(metin)}";

                using (var client = new System.Net.WebClient())
                {
                    client.Encoding = System.Text.Encoding.UTF8;
                    string html = client.DownloadString(url);

                    // Basit JSON ayiklama 
                    var parcalar = html.Split('"');
                    if (parcalar.Length > 1) return parcalar[1];
                }

                return "Ceviri yapilamadi.";
            }
            catch (Exception)
            {
                return "Baglanti hatasi olustu.";
            }
        }

        private void btnCevir_Click_1(object sender, EventArgs e)
        {
            // 1. ADIM: Giris Kontrolu
            // Kullanici metin girmeden butona basarsa uyari veriyoruz.
            if (string.IsNullOrEmpty(txtKaynak.Text))
            {
                XtraMessageBox.Show("Lutfen cevrilecek metni giriniz!");
                return;
            }

            // 2. ADIM: Dil Secimi
            // Secilen dilleri degiskenlere atiyoruz.
            string kaynakDil = comboKaynakDil.Text;
            string hedefDil = comboHedefDil.Text;

            try
            {
                // 3. ADIM: Ceviri Islemi (Logic)
                // Burada bir API veya kutuphane kullanarak metni donusturuyoruz.
                // Ornek olarak hedef kutusuna islemin basladigini yaziyoruz.
                txtHedef.Text = "Cevriliyor... Lutfen bekleyin.";

                // Matematiksel ve mantiksel olarak metin verisi isleniyor.
                string sonuc = MetniCevir(txtKaynak.Text, kaynakDil, hedefDil);

                // 4. ADIM: Sonucu Goster
                txtHedef.Text = sonuc;
            }
            catch (Exception ex)
            {
                XtraMessageBox.Show("Hata olustu: " + ex.Message);
            }
        }
    }
}
