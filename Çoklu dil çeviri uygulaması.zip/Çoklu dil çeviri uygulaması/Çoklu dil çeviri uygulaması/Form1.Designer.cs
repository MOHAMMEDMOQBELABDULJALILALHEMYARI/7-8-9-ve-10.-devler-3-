﻿namespace Çoklu_dil_çeviri_uygulaması
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtKaynak = new DevExpress.XtraEditors.MemoEdit();
            this.txtHedef = new DevExpress.XtraEditors.MemoEdit();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.comboKaynakDil = new DevExpress.XtraEditors.ComboBoxEdit();
            this.comboHedefDil = new DevExpress.XtraEditors.ComboBoxEdit();
            this.btnCevir = new DevExpress.XtraEditors.SimpleButton();
            ((System.ComponentModel.ISupportInitialize)(this.txtKaynak.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtHedef.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboKaynakDil.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboHedefDil.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // txtKaynak
            // 
            this.txtKaynak.Location = new System.Drawing.Point(19, 111);
            this.txtKaynak.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txtKaynak.Name = "txtKaynak";
            this.txtKaynak.Size = new System.Drawing.Size(245, 150);
            this.txtKaynak.TabIndex = 0;
            // 
            // txtHedef
            // 
            this.txtHedef.Location = new System.Drawing.Point(502, 111);
            this.txtHedef.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txtHedef.Name = "txtHedef";
            this.txtHedef.Size = new System.Drawing.Size(236, 150);
            this.txtHedef.TabIndex = 1;
            // 
            // labelControl1
            // 
            this.labelControl1.Location = new System.Drawing.Point(117, 42);
            this.labelControl1.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(31, 16);
            this.labelControl1.TabIndex = 3;
            this.labelControl1.Text = "Metin";
            // 
            // labelControl2
            // 
            this.labelControl2.Location = new System.Drawing.Point(604, 42);
            this.labelControl2.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(32, 16);
            this.labelControl2.TabIndex = 4;
            this.labelControl2.Text = "Çeviri";
            // 
            // comboKaynakDil
            // 
            this.comboKaynakDil.Location = new System.Drawing.Point(42, 68);
            this.comboKaynakDil.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.comboKaynakDil.Name = "comboKaynakDil";
            this.comboKaynakDil.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.comboKaynakDil.Properties.Items.AddRange(new object[] {
            "en",
            "tr"});
            this.comboKaynakDil.Size = new System.Drawing.Size(195, 22);
            this.comboKaynakDil.TabIndex = 5;
            // 
            // comboHedefDil
            // 
            this.comboHedefDil.Location = new System.Drawing.Point(522, 68);
            this.comboHedefDil.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.comboHedefDil.Name = "comboHedefDil";
            this.comboHedefDil.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.comboHedefDil.Properties.Items.AddRange(new object[] {
            "en",
            "tr"});
            this.comboHedefDil.Size = new System.Drawing.Size(195, 22);
            this.comboHedefDil.TabIndex = 6;
            // 
            // btnCevir
            // 
            this.btnCevir.Location = new System.Drawing.Point(314, 352);
            this.btnCevir.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.btnCevir.Name = "btnCevir";
            this.btnCevir.Size = new System.Drawing.Size(148, 45);
            this.btnCevir.TabIndex = 2;
            this.btnCevir.Text = "Çeviri Yap";
            this.btnCevir.Click += new System.EventHandler(this.btnCevir_Click_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 466);
            this.Controls.Add(this.comboHedefDil);
            this.Controls.Add(this.comboKaynakDil);
            this.Controls.Add(this.labelControl2);
            this.Controls.Add(this.labelControl1);
            this.Controls.Add(this.btnCevir);
            this.Controls.Add(this.txtHedef);
            this.Controls.Add(this.txtKaynak);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.txtKaynak.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtHedef.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboKaynakDil.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboHedefDil.Properties)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraEditors.MemoEdit txtKaynak;
        private DevExpress.XtraEditors.MemoEdit txtHedef;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.ComboBoxEdit comboKaynakDil;
        private DevExpress.XtraEditors.ComboBoxEdit comboHedefDil;
        private DevExpress.XtraEditors.SimpleButton btnCevir;
    }
}

