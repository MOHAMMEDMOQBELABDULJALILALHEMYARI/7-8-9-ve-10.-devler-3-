﻿namespace Virüs_Antivirüs
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.prgTarama = new DevExpress.XtraEditors.ProgressBarControl();
            this.lstSonuclar = new DevExpress.XtraEditors.ListBoxControl();
            this.btnTara = new DevExpress.XtraEditors.SimpleButton();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            ((System.ComponentModel.ISupportInitialize)(this.prgTarama.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lstSonuclar)).BeginInit();
            this.SuspendLayout();
            // 
            // prgTarama
            // 
            this.prgTarama.Location = new System.Drawing.Point(321, 243);
            this.prgTarama.Name = "prgTarama";
            this.prgTarama.Size = new System.Drawing.Size(125, 22);
            this.prgTarama.TabIndex = 0;
            // 
            // lstSonuclar
            // 
            this.lstSonuclar.Location = new System.Drawing.Point(326, 142);
            this.lstSonuclar.Name = "lstSonuclar";
            this.lstSonuclar.Size = new System.Drawing.Size(120, 95);
            this.lstSonuclar.TabIndex = 1;
            // 
            // btnTara
            // 
            this.btnTara.Location = new System.Drawing.Point(326, 271);
            this.btnTara.Name = "btnTara";
            this.btnTara.Size = new System.Drawing.Size(94, 29);
            this.btnTara.TabIndex = 2;
            this.btnTara.Text = "simpleButton1";
            this.btnTara.Click += new System.EventHandler(this.btnTara_Click);
            // 
            // labelControl1
            // 
            this.labelControl1.Location = new System.Drawing.Point(326, 120);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(82, 16);
            this.labelControl1.TabIndex = 3;
            this.labelControl1.Text = "(Safe/Danger)";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.labelControl1);
            this.Controls.Add(this.btnTara);
            this.Controls.Add(this.lstSonuclar);
            this.Controls.Add(this.prgTarama);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.prgTarama.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lstSonuclar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraEditors.ProgressBarControl prgTarama;
        private DevExpress.XtraEditors.ListBoxControl lstSonuclar;
        private DevExpress.XtraEditors.SimpleButton btnTara;
        private DevExpress.XtraEditors.LabelControl labelControl1;
    }
}

