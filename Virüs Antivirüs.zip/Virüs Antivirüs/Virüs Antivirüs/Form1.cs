﻿using DevExpress.XtraEditors;
using System;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Virüs_Antivirüs
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        
        private async void btnTara_Click(object sender, EventArgs e)
        {
            lstSonuclar.Items.Clear();
            prgTarama.Position = 0;
            btnTara.Enabled = false;

            string[] sistemDosyalari = { "System32.dll", "User.config", "Virus_Test.exe", "Boot.ini", "Malware_Sample.bat" };

            for (int i = 0; i <= 100; i += 10)
            {
                // Tarama hizi simulasyonu
                await Task.Delay(300);
                prgTarama.Position = i;

                if (i % 20 == 0 && (i / 20) < sistemDosyalari.Length)
                {
                    string dosya = sistemDosyalari[i / 20];

                    // Virus tespit mantigi
                    if (dosya.Contains("Virus") || dosya.Contains("Malware"))
                    {
                        lstSonuclar.Items.Add("[TEHLIKE] Zararli yazilim bulundu: " + dosya);
                    }
                    else
                    {
                        lstSonuclar.Items.Add("[TEMIZ] Dosya tarandi: " + dosya);
                    }
                }
            }

            XtraMessageBox.Show("Tarama Tamamlandi! Sisteminiz guvende.");
            btnTara.Enabled = true;
        }
    }
}
