﻿using DevExpress.XtraEditors;
using System;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LLM_Chatbot
{
    public partial class Form1 : DevExpress.XtraEditors.XtraForm
    {
        public Form1()
        {
            InitializeComponent();
        }

        // 'async' eklendi: 'await' kullanabilmek icin bu sarttir.
        private async void btnGonder_Click(object sender, EventArgs e)
        {
            string soru = txtSoru.Text;

            if (string.IsNullOrWhiteSpace(soru))
            {
                XtraMessageBox.Show("Lutfen bir soru giriniz!");
                return;
            }

            chatList.Items.Add("Siz: " + soru);
            txtSoru.Text = "";

            try
            {
                // Yapay zeka servisinden cevap bekleniyor
                string cevap = await GetLLMResponse(soru);

                chatList.Items.Add("Bot: " + cevap);
                chatList.SelectedIndex = chatList.Items.Count - 1;
            }
            catch (Exception ex)
            {
                chatList.Items.Add("Hata Olustu: " + ex.Message);
            }
        }

        // Yapay Zeka (LLM) Karar Mekanizmasi Simülasyonu
        public async Task<string> GetLLMResponse(string input)
        {
            await Task.Delay(1200);

            string lowerInput = input.ToLower();

            if (lowerInput.Contains("merhaba") || lowerInput.Contains("selam"))
                return "Merhaba! Size bugun nasil yardimci olabilirim?";

            if (lowerInput.Contains("kimsin") || lowerInput.Contains("nedir"))
                return "Ben DevExpress ile gelistirilmis bir LLM Chatbot simulasyonuyum.";

            if (lowerInput.Contains("saat"))
                return "Sistem saati: " + DateTime.Now.ToShortTimeString();

            if (lowerInput.Contains("tesekkur"))
                return "Rica ederim, baska bir sorunuz var mi?";

            return "Bu soruyu veri tabanimda analiz ediyorum, daha detayli sorabilirsiniz.";
        }

        private void txtSoru_EditValueChanged(object sender, EventArgs e)
        {

        }
    }
}