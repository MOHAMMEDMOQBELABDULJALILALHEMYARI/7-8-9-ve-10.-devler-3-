﻿namespace LLM_Chatbot
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.chatList = new DevExpress.XtraEditors.ListBoxControl();
            this.txtSoru = new DevExpress.XtraEditors.TextEdit();
            this.btnGonder = new DevExpress.XtraEditors.SimpleButton();
            ((System.ComponentModel.ISupportInitialize)(this.chatList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSoru.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // chatList
            // 
            this.chatList.Location = new System.Drawing.Point(12, 0);
            this.chatList.Name = "chatList";
            this.chatList.Size = new System.Drawing.Size(776, 158);
            this.chatList.TabIndex = 0;
            // 
            // txtSoru
            // 
            this.txtSoru.Location = new System.Drawing.Point(21, 164);
            this.txtSoru.Name = "txtSoru";
            this.txtSoru.Size = new System.Drawing.Size(125, 22);
            this.txtSoru.TabIndex = 1;
            this.txtSoru.EditValueChanged += new System.EventHandler(this.txtSoru_EditValueChanged);
            // 
            // btnGonder
            // 
            this.btnGonder.Location = new System.Drawing.Point(671, 164);
            this.btnGonder.Name = "btnGonder";
            this.btnGonder.Size = new System.Drawing.Size(103, 75);
            this.btnGonder.TabIndex = 2;
            this.btnGonder.Text = "simpleButton1";
            this.btnGonder.Click += new System.EventHandler(this.btnGonder_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnGonder);
            this.Controls.Add(this.txtSoru);
            this.Controls.Add(this.chatList);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.chatList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSoru.Properties)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.ListBoxControl chatList;
        private DevExpress.XtraEditors.TextEdit txtSoru;
        private DevExpress.XtraEditors.SimpleButton btnGonder;
    }
}

