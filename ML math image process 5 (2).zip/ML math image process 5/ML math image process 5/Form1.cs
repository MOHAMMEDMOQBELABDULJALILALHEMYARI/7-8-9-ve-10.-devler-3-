﻿using DevExpress.XtraEditors;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ML_math_image_process_5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAnaliz_Click(object sender, EventArgs e)
        {
            if (resimKutusu.Image == null)
            {
                XtraMessageBox.Show("Lutfen bir resim secin!");
                return;
            }

            // 1. Image Process (Resim Isleme)
            Bitmap bmp = new Bitmap(resimKutusu.Image, new Size(28, 28));

            // 2. Math Matrix (Matematiksel Matris)
            float[] matris = new float[28 * 28];

            // 3. Normalization (Veri Normallestirme)
            for (int y = 0; y < 28; y++)
            {
                for (int x = 0; x < 28; x++)
                {
                    Color c = bmp.GetPixel(x, y);
                    matris[y * 28 + x] = (c.R + c.G + c.B) / 3f / 255f;
                }
            }

            lblSonuc.Text = "Islem Basarili: Goruntu Matrise Donusturuldu.";
        }

        private void resimKutusu_EditValueChanged(object sender, EventArgs e)
        {
            // Bilgisayardan resim secmek icin pencere acar
            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                // Sadece resim dosyalarini goster
                dialog.Filter = "Resim Dosyalari|*.jpg;*.jpeg;*.png";

                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    // Secilen resmi kutuya yerlestir
                    resimKutusu.Image = Image.FromFile(dialog.FileName);
                }
            }
        }
    }
}

