﻿namespace ML_math_image_process_5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.resimKutusu = new DevExpress.XtraEditors.PictureEdit();
            this.btnAnaliz = new DevExpress.XtraEditors.SimpleButton();
            this.lblSonuc = new DevExpress.XtraEditors.LabelControl();
            ((System.ComponentModel.ISupportInitialize)(this.resimKutusu.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // resimKutusu
            // 
            this.resimKutusu.Location = new System.Drawing.Point(281, 119);
            this.resimKutusu.Name = "resimKutusu";
            this.resimKutusu.Properties.ShowCameraMenuItem = DevExpress.XtraEditors.Controls.CameraMenuItemVisibility.Auto;
            this.resimKutusu.Size = new System.Drawing.Size(174, 118);
            this.resimKutusu.TabIndex = 3;
            this.resimKutusu.EditValueChanged += new System.EventHandler(this.resimKutusu_EditValueChanged);
            // 
            // btnAnaliz
            // 
            this.btnAnaliz.Location = new System.Drawing.Point(308, 243);
            this.btnAnaliz.Name = "btnAnaliz";
            this.btnAnaliz.Size = new System.Drawing.Size(127, 57);
            this.btnAnaliz.TabIndex = 4;
            this.btnAnaliz.Text = "Analiz Et";
            this.btnAnaliz.Click += new System.EventHandler(this.btnAnaliz_Click);
            // 
            // lblSonuc
            // 
            this.lblSonuc.Location = new System.Drawing.Point(326, 97);
            this.lblSonuc.Name = "lblSonuc";
            this.lblSonuc.Size = new System.Drawing.Size(97, 16);
            this.lblSonuc.TabIndex = 5;
            this.lblSonuc.Text = "Sonuc Bekleniyor";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(796, 450);
            this.Controls.Add(this.lblSonuc);
            this.Controls.Add(this.btnAnaliz);
            this.Controls.Add(this.resimKutusu);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.resimKutusu.Properties)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private DevExpress.XtraEditors.PictureEdit resimKutusu;
        private DevExpress.XtraEditors.SimpleButton btnAnaliz;
        private DevExpress.XtraEditors.LabelControl lblSonuc;
    }
}

